# Chris Mene website — React + admin panel

## Run it
```bash
npm install
npm run dev          # http://localhost:5173 (needs src/firebaseConfig.js filled in)
```
Admin: http://localhost:5173/admin — sign in with the Firebase admin user.
Setup and deployment: see DEPLOY-FIREBASE.md.

## What the admin panel manages
- Articles: title, summary, text, cover image, video (upload or YouTube/Vimeo), extra images
- Videos: upload a file or paste a YouTube/Vimeo link, optional thumbnail
- Podcast: cover, optional audio upload, Apple/Spotify/YouTube links
- Audio: upload MP3/M4A/WAV with optional cover
- Events: title, date, large photo, small photo, badge letters, link
- Pop-up: image, text, button, delay, every page or once per visit
- Site & images: hero photos, newsletter photo + focus point, the 3 Program cards, About images
- Subscribers & messages: newsletter sign-ups (CSV export) and contact messages

Drafts stay hidden from visitors until published.

## Developer section (Admin sidebar → Developer)
- **Page content** — edit every text, link, button label and image, page by page (Site-wide, Home, About, Programs,
  Events, Platforms, Resources, Store, Connect). There is a search box, an "All buttons" tab, and a
  "Reset to default" link on anything you have changed. In headings, put *stars* around a word for italics.
- **Theme & buttons** — Primary, Secondary, Tertiary and Fourth colours, text colours, soft panels, button colours
  (on dark and on light sections) and button corner style, with a live preview.
- To make a new piece of text editable, add one line to `shared/content.js` and use `c("your.key")` in the component.

## Resources page
Videos, Podcast and Audio show two rows on any screen size, then a "View all" button (its text is editable).

## Structure
- src/components: Header, Hero, PopupModal, Newsletter, ProgramCards, UpcomingEvents, Resources
- src/pages/Pages.jsx: every public page
- src/admin: the admin panel
- src/api.js: Firebase (Firestore + Auth) data layer; public/api: PHP upload service for your hosting
- shared/seed.js: starting content and default image URLs (still pointing at chrismene.org)
