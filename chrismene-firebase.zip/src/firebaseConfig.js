// Paste the values from Firebase console → Project settings → Your apps → Web app → "firebaseConfig".
// These values are safe to publish; your data is protected by firestore.rules, not by hiding them.
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_APP_ID",
};
